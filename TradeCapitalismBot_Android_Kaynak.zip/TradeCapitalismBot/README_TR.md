# Trade Capitalism Bot — Android kaynak projesi (MVP)

Bu ZIP, kurulabilir APK değil; Android Studio ile derlenebilen başlangıç kaynak projesidir.

## Özellikler
- Kullanıcı yüklü uygulamalar arasından oyunu seçer.
- Android Erişilebilirlik Servisi, oyun öndeyken ekrandaki “Tümünü Topla” metnini arar.
- Metni bulursa ilgili erişilebilir düğmeye basmayı dener.
- 30 dakikada bir reklamı elle izleme bildirimi verir.
- 6 saatte bir oyuna dönüp tahsilatı kontrol etme bildirimi verir.
- Bot kullanıcı tarafından durdurulabilir.

## Sınırlamalar
- Reklam tıklama/izleme otomasyonu yoktur.
- İlk MVP, oyun erişilebilirlik ağacında “Tümünü Topla” metnini göstermiyorsa çalışmayabilir. Oyun özel çizim kullanıyorsa ekran görüntüsü/koordinat tabanlı uyarlama gerekir.
- Android arka plan kısıtlamaları nedeniyle bu sürüm oyunu kendi kendine her koşulda öne getirmez. Gelir toplama için oyunun ekranda açık olması gerekir.
- Android üreticisinin pil optimizasyonu servisi durdurabilir.
- Oyun kuralları otomasyona izin vermeyebilir; hesabın riskini kontrol et.

## Derleme
1. ZIP'i bilgisayarda Android Studio ile aç.
2. Gradle senkronizasyonunu tamamla.
3. Telefonu USB hata ayıklama ile bağla veya APK oluştur: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK'yı telefona kur.
5. Uygulamayı aç, Trade Capitalism'i seç.
6. “Erişilebilirlik iznini aç” bölümünden “TC gelir toplama servisi”ni etkinleştir.
7. Oyunu aç ve ekranda “İşletmelerim” sayfasında bırak.

Bu sürüm deneme/MVP'dir; gerçek oyunda test edilmeden çalışacağı garanti edilmez.
