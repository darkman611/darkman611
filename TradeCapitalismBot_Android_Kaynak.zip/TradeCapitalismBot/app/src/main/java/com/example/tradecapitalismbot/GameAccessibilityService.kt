package com.example.tradecapitalismbot

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat

class GameAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("tc_bot", Context.MODE_PRIVATE) }
    private var lastCollect = 0L
    private var lastAdReminder = 0L
    private var lastSixHour = 0L
    private val tick = object : Runnable {
        override fun run() {
            if (prefs.getBoolean("enabled", false)) {
                val now = System.currentTimeMillis()
                val target = prefs.getString("game_package", "") ?: ""
                val root = rootInActiveWindow
                if (root != null && target.isNotBlank() && root.packageName?.toString() == target) {
                    if (now - lastCollect >= 5 * 60 * 1000L) {
                        val clicked = clickCollect(root)
                        if (clicked) lastCollect = now
                    }
                }
                if (lastAdReminder == 0L) lastAdReminder = now
                if (now - lastAdReminder >= 30 * 60 * 1000L) {
                    notifyUser("Reklam zamanı", "Oyundaki reklam ödülünü istersen elle izle ve ödülü al.")
                    lastAdReminder = now
                }
                if (lastSixHour == 0L) lastSixHour = now
                if (now - lastSixHour >= 6 * 60 * 60 * 1000L) {
                    notifyUser("6 saatlik oyun kontrolü", "Trade Capitalism'i açıp tahsilatın devam ettiğini kontrol et.")
                    lastSixHour = now
                }
            }
            handler.postDelayed(this, 15_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        createChannel()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Periyodik kontrol tick içinde yapılır; ekran olayları burada işlem gerektirmez.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun clickCollect(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (text.contains("tümünü topla") || desc.contains("tümünü topla") ||
            text.contains("tumunu topla") || desc.contains("tumunu topla")) {
            var target: AccessibilityNodeInfo? = node
            while (target != null) {
                if (target.isClickable) return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                target = target.parent
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (clickCollect(child)) return true
        }
        return false
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("tc_bot", "TC Bot hatırlatmaları", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun notifyUser(title: String, body: String) {
        val launch = packageManager.getLaunchIntentForPackage(prefs.getString("game_package", "") ?: "")
            ?: Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, title.hashCode(), launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, "tc_bot")
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle(title).setContentText(body).setAutoCancel(true)
            .setContentIntent(pending).build()
        getSystemService(NotificationManager::class.java).notify(title.hashCode(), notification)
    }
}
