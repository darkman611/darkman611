package com.example.tradecapitalismbot

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tc_bot", Context.MODE_PRIVATE) }
    private var selectedLabel = "Oyun seçilmedi"
    private var selectedPackage = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedLabel = prefs.getString("game_label", selectedLabel) ?: selectedLabel
        selectedPackage = prefs.getString("game_package", "") ?: ""
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        fun button(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label }
            layout.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 14
            })
            b.setOnClickListener { action() }
        }
        val intro = TextView(this).apply {
            text = "TRADE CAPITALISM OTOMASYON\\n\\nOyun açık ve ekranda iken 5 dakikada bir “Tümünü Topla” düğmesini arar. Reklam ve 6 saatlik kontrol için bildirim verir. Reklamı otomatik tıklamaz."
            textSize = 17f
            setPadding(0, 0, 0, 24)
        }
        layout.addView(intro)
        val game = TextView(this).apply { text = "Seçili oyun: $selectedLabel"; textSize = 16f; setPadding(0,0,0,20) }
        layout.addView(game)
        button("Yüklü oyunlardan seç") {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            val labels = apps.map { "${it.loadLabel(pm)} (${it.activityInfo.packageName})" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Trade Capitalism uygulamasını seç")
                .setItems(labels) { _, which ->
                    val info = apps[which].activityInfo
                    selectedLabel = info.loadLabel(pm).toString()
                    selectedPackage = info.packageName
                    prefs.edit().putString("game_label", selectedLabel).putString("game_package", selectedPackage).apply()
                    game.text = "Seçili oyun: $selectedLabel"
                }.show()
        }
        button("Erişilebilirlik iznini aç") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("Botu başlat") {
            if (selectedPackage.isBlank()) {
                Toast.makeText(this, "Önce oyunu seç.", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putBoolean("enabled", true).apply()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this, "Listeden TC gelir toplama servisini etkinleştir. Sonra oyunu aç.", Toast.LENGTH_LONG).show()
            }
        }
        button("Botu durdur") {
            prefs.edit().putBoolean("enabled", false).apply()
            Toast.makeText(this, "Bot durduruldu.", Toast.LENGTH_SHORT).show()
        }
        button("Oyunu aç") {
            if (selectedPackage.isNotBlank()) {
                packageManager.getLaunchIntentForPackage(selectedPackage)?.let { startActivity(it) }
            }
        }
        val note = TextView(this).apply {
            text = "\\nNot: İlk sürüm ekrandaki erişilebilir metni okuyabilirse çalışır. Oyun “Tümünü Topla” yazısını erişilebilirlik ağacına sunmuyorsa ek uyarlama gerekir. Android, arka planda oyunu zorla açmayı kısıtlayabilir."
            textSize = 13f
        }
        layout.addView(note)
        setContentView(layout)
    }
}
